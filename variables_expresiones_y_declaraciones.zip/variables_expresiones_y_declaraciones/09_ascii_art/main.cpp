// ASCII ART CON UNICODE
#include <iostream>

using namespace std;

int main()
{
  // Para utilizar los caracteres UNICODE podemos copiarlos y pegarlos
  // directamente.
  // También podemos escribir su código presionando Ctrl + Shift + u.
  // Ej: Ctrl + Shift + u y luego 256c imprime ╬
  // También se pueden imprimir usando el caracter de escape \u o \U.
  // \uxxxx : si el código hexadecimal tiene 4 caracteres o menos.
  // \Uxxxxxxxx : si el código hexadecimal tiene más de 4 caracteres.
  // Ejemplo: \u256c imprime ╬
  // Ejemplo; \U0001f3b8 imprime 🎸

  cout << "Uso de caracteres de dibujo UNICODE" << endl;
  
  cout << "Usando el caracter de escape con el código: \u256c" << endl;
  cout << "Usando el símbolo unicode directamente: ╬" << endl;
  cout << "Usando el caracter de escape con el código: \U0001f3b8" << endl;
  cout << "Usando el símbolo unicode directamente: 🎸" << endl;
  cout << endl;
  //! Ejecutar

  cout << "Uso de caracteres ASCII básicos" << endl;
  cout << "EL GATITO Y LA TV" << endl
       << endl;
  cout << "╔══════════════════════════════╗" << endl;
  cout << "║     __________               ║" << endl;
  cout << "║    / │┌──────┐│   /\\___/\\    ║" << endl;
  cout << "║    │ ││      ││  ( ^ w ^ )   ║" << endl;
  cout << "║    │ │└──────┘│C= /‾‾‾‾‾‾‾/  ║" << endl;
  cout << "║    └─┴────────┘  /       /   ║" << endl;
  cout << "║    ├──────\\___( /_______/    ║" << endl;
  cout << "║    │           ││       │    ║" << endl;
  cout << "║                              ║ " << endl;
  cout << "╚══════════════════════════════╝" << endl;

  cout << endl;
  return 0;
}