#include <iostream>
using namespace std;

int main()
{
  const int PUNTOS_POR_ALIEN = 15;
  int aliens_muertos = 10;
  int puntaje = aliens_muertos * PUNTOS_POR_ALIEN;

  cout << "Destruimos " << aliens_muertos << " aliens." << endl;
  cout << "Puntaje Total: " << puntaje << endl;

  enum costoNave
  {
    COSTO_FIGHTER = 24,
    COSTO_BOMBER,
    COSTO_CRUCERO = 50
  };

  // Mi nave es un BOMBER, que cuesta 25: 24 (COSTO_FIGHTER) + 1.
  costoNave costoDeMiNave = COSTO_BOMBER;

  cout << "\nActualizar mi nave de BOMBER a CRUCERO tiene un costo de " << (COSTO_CRUCERO - costoDeMiNave) << " Puntos.\n";

  cout << endl;
  return 0;
}
