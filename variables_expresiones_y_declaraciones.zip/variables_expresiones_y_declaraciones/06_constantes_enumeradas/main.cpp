// Constantes enumeradas.

#include <iostream>

using namespace std;

int main()
{
  enum estaciones
  {
    VERANO,
    OTONIO,
    INVIERNO,
    PRIMAVERA
  };

  estaciones estacion = OTONIO;

  cout << "Estamos en la estación número " << estacion + 1 << " del año." << endl;

  // El enum solo (sin class) funciona como si el contenido fuesen
  // variables globales, por lo que no podría tener otro enum que
  // repita alguna de las constantes.
  /// enum posicion { ARRIBA, ABAJO, IZQUIERDA, DERECHA };
  /// enum lado { IZQUIERDA, DERECHA, NINGUNO }; // Da error

  // En cambio esto no da error porque el compilador se da cuenta que
  // las constante pertenecen a enums diferentes:
  enum class posicion
  {
    ARRIBA,
    ABAJO,
    IZQUIERDA,
    DERECHA
  };

  enum class lado
  {
    IZQUIERDA,
    DERECHA,
    NINGUNO
  };

  // Si declaramos los enum con class, cuando los asignemos tendremos
  // que especificar el ámbito de la siguiente manera:
  posicion pos = posicion::IZQUIERDA;
  lado l = lado::IZQUIERDA;

  // Si queremos emitir por pantalla un enum class usando '<<' tenemos
  // que castear el tipo, es decir, tenemos que explicitar que el valor
  // del enumerador es un entero, utilizando (int).
  cout << "\nLa posición corresponde al entero: " << (int)pos << endl;

  if (pos == posicion::ARRIBA)
    cout << "Posición ARRIBA." << endl;
  else if (pos == posicion::ABAJO)
    cout << "Posición ABAJO." << endl;
  else if (pos == posicion::IZQUIERDA)
    cout << "Posición IZQUIERDA." << endl;
  else
    cout << "Posición DERECHA." << endl;

  cout << endl;

  cout << "El lado corresponde al entero: " << (int)l << endl;

  if (l == lado::DERECHA)
    cout << "Lado DERECHA." << endl;
  else if (l == lado::IZQUIERDA)
    cout << "Lado IZQUIERDA." << endl;
  else
    cout << "Lado NINGUNO." << endl;

  cout << endl;
  return 0;
}