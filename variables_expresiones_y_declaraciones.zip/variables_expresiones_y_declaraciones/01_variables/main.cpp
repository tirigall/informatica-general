// Ejemplo de variables

#include <iostream>
using namespace std;

int main()
{
  short int Ancho = 5, Largo;
  Largo = 10;

  // Creamos una variable unsigned short y la inicializamos
  // con el resultado de multiplicar Ancho por Largo.

  short int Area = (Ancho * Largo);

  cout << "Ancho:" << Ancho << "\n";
  cout << "Largo: " << Largo << endl;
  cout << "Area: " << Area << endl;

  return 0;
}