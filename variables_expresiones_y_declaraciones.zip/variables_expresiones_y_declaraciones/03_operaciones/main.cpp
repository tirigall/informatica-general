// Ejemplo división

#include <iostream>
using namespace std;

int main()
{
  /*
  int resultado;
  int numerador = 5;
  int denominador = 3;
  int resto = numerador % denominador;
  resultado = numerador / denominador;

  cout << "Resto de la división entera 5/3 es: " << resto << endl;	
  cout << "Resultado de 5/3 es: " << resultado << endl;
  */

  // Testeo con valores flotantes
  int resultado; // Luego cambiar por float resultado;
  float numerador = 5;
  float denominador = 3;
  resultado = numerador / denominador;
  cout << "Resultado de 5/3 es: " << resultado << endl;

  cout << endl;
  return 0;
}