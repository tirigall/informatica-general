// Posfijo con los operadores de incremento y decremento.

#include <iostream>

using namespace std;

int main()
{

  int miEdad = 39;

  cout << "Yo tengo: " << miEdad << " años de edad.\n";

  miEdad++; // incremento posfijo

  cout << "Pasado un año...\n";
  cout << "Yo tengo: " << miEdad << " años de edad.\n";

  cout << "Pasa otro año...\n";
  miEdad++;
  cout << "Yo tengo: " << miEdad << " años de edad.\n";

  cout << "Pasan cinco año...\n";
  /// miEdad = miEdad + 5
  miEdad += 5;
  cout << "Yo tengo: " << miEdad << " años de edad.\n";

  cout << endl;
  return 0;
}