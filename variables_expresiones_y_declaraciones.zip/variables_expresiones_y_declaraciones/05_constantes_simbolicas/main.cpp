// Constantes Simbólicas

#include <iostream>

using namespace std;

int main()
{
  const int VERANO = 0;
  const int OTONIO = 1;
  const int INVIERNO = 2;
  const int PRIMAVERA = 3;

  int estacion = OTONIO;

  cout << "Estamos en la estación número " << estacion + 1 << " del año." << endl;

  cout << endl;
  return 0;
}