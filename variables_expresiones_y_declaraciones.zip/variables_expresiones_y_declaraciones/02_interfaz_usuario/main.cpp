/*********************************************************************\
 Interfaz de Usuario:
 Muestra el número de vidas, puntos, nivel de salud y armadura, etc.,
 dependiendo del juego.

\*********************************************************************/

#include <iostream>
using namespace std;

int main()
{
  int puntaje;
  float distancia_al_objetivo;
  char jugarDeNuevo;
  bool escudos;

  int vidas, aliensMuertos;

  puntaje = 0;
  distancia_al_objetivo = 1200.76f;
  jugarDeNuevo = 's';
  escudos = true;
  vidas = 3;
  aliensMuertos = 10;

  cout << "Estás en tu nave espacial...\n" << endl;
  cout << "Información" << endl;
  cout << "puntaje: " << puntaje << endl;
  cout << "distancia_al_objetivo: " << distancia_al_objetivo << " Kms." << endl;
  cout << "jugarDeNuevo: " << jugarDeNuevo << endl;
  cout << "escudos: " << escudos << endl;
  cout << "vidas: " << vidas << endl;
  cout << "aliensMuertos: " << aliensMuertos << endl;

  int combustible;
  cout << endl;
  cout << "Cantidad de combustible para cargar?: ";

  // 'cin' console input, lee el valor ingresado por el usuario en la
  // consola y lo coloca dentro de la variable 'combustible'.
  // Como 'cout', 'cin' es un objeto definido en 'iostream', el cual se
  // encuentra en el namespace 'std'. Para guardar un valor en una
  // variable usamos 'cin' seguido de '>>' (el operador de extracción
  // de flujo) seguido del nombre de la variable.
  cin >> combustible;

  cout << "combustible: " << combustible << endl;

  int bonus = 10;
  cout << "\nbonus: " << bonus << endl;

  cout << endl;
  return 0;
}
