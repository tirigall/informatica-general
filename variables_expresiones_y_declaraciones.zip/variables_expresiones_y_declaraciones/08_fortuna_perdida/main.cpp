// FORTUNA PERDIDA
// Narración escrita en la consola en base a ciertas palabras
// ingresadas por el usuario.

#include <iostream>
#include <string>

using namespace std;

int main()
{
  const int PIEZAS_DE_ORO = 900;
  int aventureros, asesinados, sobrevivientes;

  // El tipo string me permite guardar oraciones (conjunto de
  // caracteres).
  string lider;

  // Obtener información
  cout << "Bienvenido a *** El Tesoro Perdido ***\n\n";

  cout << "Por favor, introduzca los siguientes datos para su aventura personalizada.\n";

  cout << "Ingrese un número: ";
  cin >> aventureros;

  cout << "Ingrese un número, mas pequeño que el anterior: ";
  cin >> asesinados;

  sobrevivientes = aventureros - asesinados;

  cout << "Ingrese su nombre: ";
  cin >> lider;

  // Redacción de la historia
  cout << "\nUn grupo de " << aventureros << " valientes aventureros partieron en una misión\n";
  cout << "-- en busca del tesoro perdido de los Antiguos Enanos --.\n";
  cout << "El grupo estaba dirigido por el legendario guerrero, " << lider << ".\n";

  cout << "\nEn el camino, una banda de ogros merodeadores emboscaron al grupo.\n";
  cout << "Todos lucharon valientemente bajo el mando de\n" << lider;
  cout << ", y los ogros fueron derrotados, pero con un costo.\n";
  cout << "De todos los aventureros, " << asesinados << " fueron vencidos,\n";
  cout << "quedando solo " << sobrevivientes << " sobrevivientes en el grupo.\n";

  cout << "\nEl grupo estuvo a punto de perder toda esperanza.\n";
  cout << "Pero mientras caminaban, lamentándose por los difuntos que yacían detrás,\n";
  cout << "se toparon con una gran X en el suelo que marcaba la fortuna enterrada.\n";
  cout << "Por lo que los aventureros se repartieron las " << PIEZAS_DE_ORO << " piezas de oro.\n";

  // Mostramos el porcentaje de sobrevivientes.
  cout << lider << " se llevó el " << (sobrevivientes * 100 / aventureros) << " % de las";

  cout << " piezas de oro por mantener vivos a " << sobrevivientes << "\nsobrevivientes.\n";

  cout << endl;
  return 0;
}
